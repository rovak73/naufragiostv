<?php

/**
 * Class WPBakeryShortCode_VC_Message
 * @deprecated since 4.4
 */
class WPBakeryShortCode_VC_Message extends WPBakeryShortCode {
	public function outputTitle( $title ) {
		return '';
	}
}